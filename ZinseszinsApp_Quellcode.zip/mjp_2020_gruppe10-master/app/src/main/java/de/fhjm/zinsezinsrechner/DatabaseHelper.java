package de.fhjm.zinsezinsrechner;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TABLE_NAME = "calculations";
    private static final String COL1 = "ID";
    private static final String COL2 = "searchedValue";
    private static final String COL3 = "initialCapital";
    private static final String COL4 = "interestRate";
    private static final String COL5 = "operationalTime";
    private static final String COL6 = "finalCapital";
    private static final String COL7 = "comment";
    private static final String COL8 = "date";

    DatabaseHelper(@Nullable Context context) {
        super(context, TABLE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String dropTable;
        dropTable = "DROP TABLE IF EXISTS " +  TABLE_NAME;
        db.execSQL(dropTable);
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL1 + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL2 + " TEXT NOT NULL, " +
                COL3 + " DOUBLE NOT NULL, " +
                COL4 + " DOUBLE NOT NULL, " +
                COL5 + " DOUBLE NOT NULL, " +
                COL6 + " DOUBLE NOT NULL, " +
                COL7 + " TEXT, " +
                COL8 + " DATE NOT NULL)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    boolean addData(Calculation calculation){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.putNull(COL1);
        cv.put(COL2, calculation.getSearchedValue());
        cv.put(COL3, calculation.getInitialCapital());
        cv.put(COL4, calculation.getInterestRate());
        cv.put(COL5, calculation.getOperationalTime());
        cv.put(COL6, calculation.getFinalCapital());
        cv.put(COL7, calculation.getComment());
        cv.put(COL8, String.valueOf(calculation.getDate()));

        long result = db.insert(TABLE_NAME, null, cv);
        return result != -1;
    }

    ArrayList<Calculation> getData(){
        ArrayList<Calculation> savedCalculations = new ArrayList<>();
        Calculation calculation;
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()){
            calculation = new Calculation(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COL1))),
                    Double.parseDouble(cursor.getString(cursor.getColumnIndex(COL4))),
                    Double.parseDouble(cursor.getString(cursor.getColumnIndex(COL5))),
                    Double.parseDouble(cursor.getString(cursor.getColumnIndex(COL3))),
                    Double.parseDouble(cursor.getString(cursor.getColumnIndex(COL6))),
                    cursor.getString(cursor.getColumnIndex(COL2)),
                    cursor.getString(cursor.getColumnIndex(COL7)));
            savedCalculations.add(calculation);
        }
        cursor.close();
        return savedCalculations;
    }

    void deleteData(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + TABLE_NAME + " WHERE " + COL1 + " = " + id + ";";
        db.execSQL(query);
    }

    void updateData(Calculation calculation){
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "UPDATE " + TABLE_NAME + " SET " + COL7 + " = '" + calculation.getComment() + "' WHERE " + COL1 + " = " + calculation.getId() + ";";
        db.execSQL(query);
    }
}
