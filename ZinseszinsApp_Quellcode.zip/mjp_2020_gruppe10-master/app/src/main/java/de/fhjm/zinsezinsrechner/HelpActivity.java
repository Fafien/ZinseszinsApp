package de.fhjm.zinsezinsrechner;

import android.os.Bundle;
import com.google.android.material.navigation.NavigationView;

public class HelpActivity extends BasicActivity implements NavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    protected int getLayoutResourceId() {
        return R.layout.activity_help;
    }
}
