package de.fhjm.zinsezinsrechner;

import java.io.Serializable;
import java.util.Date;

import androidx.annotation.Nullable;

public class Calculation implements Serializable {

    private int id;
    private double interestRate;
    private double operationalTime;
    private double initialCapital;
    private double finalCapital;
    private String searchedValue;
    private String comment;
    private Date date;

    Calculation(int id, double interestRate, double operationalTime, double initialCapital, double finalCapital, String searchedValue, @Nullable String comment){
        this.id = id;
        this.interestRate = interestRate;
        this.operationalTime = operationalTime;
        this.initialCapital = initialCapital;
        this.finalCapital = finalCapital;
        this.searchedValue = searchedValue;
        this.comment = comment;
        this.date = new Date();
    }

    Calculation(){
        this.date = new Date();
    }

    void setFinalCapital(double finalCapital) {
        this.finalCapital = finalCapital;
    }

    void setInitialCapital(double initialCapital) {
        this.initialCapital = initialCapital;
    }

    void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

    void setOperationalTime(double operationalTime) {
        this.operationalTime = operationalTime;
    }

    void setSearchedValue(String searchedValue) {
        this.searchedValue = searchedValue;
    }

    void setComment(String comment) {
        this.comment = comment;
    }

    Date getDate() {
        return date;
    }

    String getComment() {
        return comment;
    }

    String getSearchedValue() {
        return searchedValue;
    }

    double getFinalCapital() {
        return finalCapital;
    }

    double getInitialCapital() {
        return initialCapital;
    }

    double getInterestRate() {
        return interestRate;
    }

    double getOperationalTime() {
        return operationalTime;
    }

    void calculateInitialCapital(){
        initialCapital = finalCapital / Math.pow(1 + interestRate / 100, operationalTime);
        initialCapital = (double)Math.round(initialCapital * 100) / 100;
    }

    void calculateInterestRate(){
        interestRate = (Math.pow(finalCapital / initialCapital, 1 / operationalTime) - 1) * 100;
        interestRate = (double)Math.round(interestRate * 100) / 100;
    }

    void calculateOperationalTime(){
        operationalTime = Math.log(finalCapital / initialCapital) / Math.log(1 + interestRate / 100);
        operationalTime = (double)Math.round(operationalTime * 100) / 100;
    }

    void calculateFinalCapital(){
        finalCapital = initialCapital * Math.pow((1 + interestRate / 100), operationalTime);
        finalCapital = (double)Math.round(finalCapital * 100) / 100;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
