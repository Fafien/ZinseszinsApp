package de.fhjm.zinsezinsrechner;

import androidx.appcompat.app.AppCompatDelegate;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;

public class SettingsActivity extends BasicActivity implements CompoundButton.OnCheckedChangeListener {

    protected Switch s_darkMode;
    protected CheckBox cb_darkMode;
    protected SharedPreferences settings;
    protected SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        cb_darkMode = findViewById(R.id.checkBox_darkMode);
        s_darkMode  = findViewById(R.id.switch_darkMode);

        s_darkMode.setOnCheckedChangeListener(this);
        cb_darkMode.setOnCheckedChangeListener(this);

        settings = getApplicationContext().getSharedPreferences("zinseszinsPreferences", MODE_PRIVATE);

        if (settings.getBoolean("darkModeSystemSettings", false)){
            cb_darkMode.setChecked(true);
            s_darkMode.setClickable(false);
        }else{
            cb_darkMode.setChecked(false);
            s_darkMode.setClickable(true);
            if (settings.getBoolean("darkMode", false)){
                s_darkMode.setChecked(true);
            }else{
                s_darkMode.setChecked(false);
            }
        }
    }

    @Override
    protected int getLayoutResourceId() {
        return R.layout.activity_settings;
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        settings = getApplicationContext().getSharedPreferences("zinseszinsPreferences", MODE_PRIVATE);
        editor = settings.edit();

        if(buttonView.equals(findViewById(R.id.checkBox_darkMode))){
            if (isChecked){
                editor.putBoolean("darkModeSystemSettings", true);
                s_darkMode.setClickable(false);
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
            }else{
                s_darkMode.setClickable(true);
                editor.putBoolean("darkModeSystemSettings", false);
                if (s_darkMode.isChecked()){
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                    editor.putBoolean("darkMode", true);
                }else{
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                    editor.putBoolean("darkMode", false);
                }
            }
        }else if(buttonView.equals((findViewById(R.id.switch_darkMode))) && !settings.getBoolean("darkModeSystemSettings", false)){
            if (isChecked){
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                editor.putBoolean("darkMode", true);
            }else{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                editor.putBoolean("darkMode", false);
            }
        }
        editor.apply();
    }

}
