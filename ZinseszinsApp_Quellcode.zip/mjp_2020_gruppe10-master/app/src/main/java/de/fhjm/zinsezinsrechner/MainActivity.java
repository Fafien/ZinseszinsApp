package de.fhjm.zinsezinsrechner;

import androidx.appcompat.app.AppCompatDelegate;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends BasicActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    protected Intent intent;

    protected Button calculateButton = null;

    protected EditText inputVariableA = null;
    protected EditText inputVariableB = null;
    protected EditText inputVariableC = null;

    protected Spinner spinner_searchedValue = null;

    protected Calculation calculation;

    protected SharedPreferences settings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        calculateButton         = findViewById(R.id.buttonCalculate);
        spinner_searchedValue   = findViewById(R.id.spinner_searchedValue);
        inputVariableA          = findViewById(R.id.inputVariableA);
        inputVariableB          = findViewById(R.id.inputVariableB);
        inputVariableC          = findViewById(R.id.inputVariableC);

        calculateButton.setOnClickListener(this);

        spinner_searchedValue.setOnItemSelectedListener(this);

        inputVariableA.setVisibility(View.GONE);
        inputVariableB.setVisibility(View.GONE);
        inputVariableC.setVisibility(View.GONE);
        calculateButton.setVisibility(View.GONE);

        settings = getApplicationContext().getSharedPreferences("zinseszinsPreferences", MODE_PRIVATE);

        if (settings.getBoolean("darkModeSystemSettings", false)){
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
        }else{
            if (settings.getBoolean("darkMode", false)){
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            }else{
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }
        }
    }

    @Override
    public void onClick(View v) {
        calculation = new Calculation();
        if (inputVariableA.getText().toString().isEmpty() || inputVariableB.getText().toString().isEmpty() || inputVariableC.getText().toString().isEmpty()) {
            Toast.makeText(getApplicationContext(), getString(R.string.label_emptyField), Toast.LENGTH_LONG).show();
        } else {
            switch (spinner_searchedValue.getSelectedItemPosition()) {
                case 1:
                    calculation.setInterestRate((double) Math.round(Double.parseDouble(inputVariableA.getText().toString()) * 100) / 100);
                    calculation.setOperationalTime((double) Math.round(Double.parseDouble(inputVariableB.getText().toString()) * 100) / 100);
                    calculation.setFinalCapital((double) Math.round(Double.parseDouble(inputVariableC.getText().toString()) * 100) / 100);
                    calculation.setSearchedValue(spinner_searchedValue.getSelectedItem().toString());
                    break;
                case 2:
                    calculation.setInterestRate((double) Math.round(Double.parseDouble(inputVariableB.getText().toString()) * 100) / 100);
                    calculation.setInitialCapital((double) Math.round(Double.parseDouble(inputVariableA.getText().toString()) * 100) / 100);
                    calculation.setFinalCapital((double) Math.round(Double.parseDouble(inputVariableC.getText().toString()) * 100) / 100);
                    calculation.setSearchedValue(spinner_searchedValue.getSelectedItem().toString());
                    if (calculation.getInitialCapital() >= calculation.getFinalCapital()){
                        Toast.makeText(getApplicationContext(), getString(R.string.label_initial_ge_final), Toast.LENGTH_LONG).show();
                        return;
                    }
                    break;
                case 3:
                    calculation.setInitialCapital((double) Math.round(Double.parseDouble(inputVariableA.getText().toString()) * 100) / 100);
                    calculation.setOperationalTime((double) Math.round(Double.parseDouble(inputVariableB.getText().toString()) * 100) / 100);
                    calculation.setFinalCapital((double) Math.round(Double.parseDouble(inputVariableC.getText().toString()) * 100) / 100);
                    calculation.setSearchedValue(spinner_searchedValue.getSelectedItem().toString());
                    if (calculation.getInitialCapital() >= calculation.getFinalCapital()){
                        Toast.makeText(getApplicationContext(), getString(R.string.label_initial_ge_final), Toast.LENGTH_LONG).show();
                        return;
                    }
                    break;
                case 4:
                    calculation.setInterestRate((double) Math.round(Double.parseDouble(inputVariableB.getText().toString()) * 100) / 100);
                    calculation.setInitialCapital((double) Math.round(Double.parseDouble(inputVariableA.getText().toString()) * 100) / 100);
                    calculation.setOperationalTime((double) Math.round(Double.parseDouble(inputVariableC.getText().toString()) * 100) / 100);
                    calculation.setSearchedValue(spinner_searchedValue.getSelectedItem().toString());
                    break;
            }

            intent = new Intent(this, ResultActivity.class);
            intent.putExtra("calculation", calculation);
            //intent.putExtra("index", spinner_searchedValue.getSelectedItemPosition());
            startActivity(intent);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (position){
            case 0:
                inputVariableA.setHint("");
                inputVariableB.setHint("");
                inputVariableC.setHint("");
                inputVariableA.setText("");
                inputVariableB.setText("");
                inputVariableC.setText("");
                inputVariableA.setVisibility(View.GONE);
                inputVariableB.setVisibility(View.GONE);
                inputVariableC.setVisibility(View.GONE);
                calculateButton.setVisibility(View.GONE);
                break;
            case 1:
                inputVariableA.setHint(getString(R.string.label_interestRate));
                inputVariableB.setHint(getString(R.string.label_operationalTime));
                inputVariableC.setHint(getString(R.string.label_finalCapital));
                inputVariableA.setText("");
                inputVariableB.setText("");
                inputVariableC.setText("");
                inputVariableA.setVisibility(View.VISIBLE);
                inputVariableB.setVisibility(View.VISIBLE);
                inputVariableC.setVisibility(View.VISIBLE);
                calculateButton.setVisibility(View.VISIBLE);
                break;
            case 2:
                inputVariableA.setHint(getString(R.string.label_initialCapital));
                inputVariableB.setHint(getString(R.string.label_interestRate));
                inputVariableC.setHint(getString(R.string.label_finalCapital));
                inputVariableA.setText("");
                inputVariableB.setText("");
                inputVariableC.setText("");
                inputVariableA.setVisibility(View.VISIBLE);
                inputVariableB.setVisibility(View.VISIBLE);
                inputVariableC.setVisibility(View.VISIBLE);
                calculateButton.setVisibility(View.VISIBLE);
                break;
            case 3:
                inputVariableA.setHint(getString(R.string.label_initialCapital));
                inputVariableB.setHint(getString(R.string.label_operationalTime));
                inputVariableC.setHint(getString(R.string.label_finalCapital));
                inputVariableA.setText("");
                inputVariableB.setText("");
                inputVariableC.setText("");
                inputVariableA.setVisibility(View.VISIBLE);
                inputVariableB.setVisibility(View.VISIBLE);
                inputVariableC.setVisibility(View.VISIBLE);
                calculateButton.setVisibility(View.VISIBLE);
                break;
            case 4:
                inputVariableA.setHint(getString(R.string.label_initialCapital));
                inputVariableB.setHint(getString(R.string.label_interestRate));
                inputVariableC.setHint(getString(R.string.label_operationalTime));
                inputVariableA.setText("");
                inputVariableB.setText("");
                inputVariableC.setText("");
                inputVariableA.setVisibility(View.VISIBLE);
                inputVariableB.setVisibility(View.VISIBLE);
                inputVariableC.setVisibility(View.VISIBLE);
                calculateButton.setVisibility(View.VISIBLE);
                break;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        inputVariableA.setVisibility(View.GONE);
        inputVariableB.setVisibility(View.GONE);
        inputVariableC.setVisibility(View.GONE);
        calculateButton.setVisibility(View.GONE);
    }

    @Override
    protected int getLayoutResourceId() {
        return R.layout.activity_main;
    }

}
