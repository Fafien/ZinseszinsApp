package de.fhjm.zinsezinsrechner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;

import java.util.Objects;

public abstract class BasicActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    protected Intent intent;
    protected DrawerLayout drawerLayout;
    protected Toolbar toolbar;
    protected NavigationView navigationView;
    protected ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayoutResourceId());

        //Entwicklung Navigationbar
        drawerLayout    = findViewById(R.id.drawerLayout);
        toolbar         = findViewById(R.id.toolbar);
        navigationView  = findViewById(R.id.navigationView);

        setSupportActionBar(toolbar);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(false);

        toggle = new ActionBarDrawerToggle(this, drawerLayout,toolbar,R.string.drawerOpen,R.string.drawerClose);

        drawerLayout.addDrawerListener(toggle);

        toggle.syncState();

        intent = getIntent();

        if(!intent.hasExtra("newSelectedItemId")){
            navigationView.getMenu().getItem(0).setChecked(true);
        }else{
            if (intent.hasExtra("oldSelectedItemId")){
                navigationView.getMenu().findItem(intent.getIntExtra("oldSelectedItemId", 0)).setChecked(false);
            }
            intent.putExtra("oldSelectedItemId", intent.getIntExtra("newSelectedItemId", 0));
            navigationView.getMenu().findItem(intent.getIntExtra("newSelectedItemId", 0)).setChecked(true);
        }
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        if(!(item.getItemId() == intent.getIntExtra("newSelectedItemId", 0))) {
            switch (item.getItemId()) {
                case R.id.calculation:
                    intent = new Intent(this, MainActivity.class);
                    intent.putExtra("newSelectedItemId", item.getItemId());
                    startActivity(intent);
                    break;
                case R.id.help:
                    intent = new Intent(this, HelpActivity.class);
                    intent.putExtra("newSelectedItemId", item.getItemId());
                    startActivity(intent);
                    item.setChecked(true);
                    break;
                case R.id.savedCalculations:
                    intent = new Intent(this, SavedcalculationsActivity.class);
                    intent.putExtra("newSelectedItemId", item.getItemId());
                    startActivity(intent);
                    item.setChecked(true);
                    break;
                case R.id.settings:
                    intent = new Intent(this, SettingsActivity.class);
                    intent.putExtra("newSelectedItemId", item.getItemId());
                    startActivity(intent);
                    item.setChecked(true);
                    break;
            }
        }
        return false;
    }

    protected abstract int getLayoutResourceId();
}
