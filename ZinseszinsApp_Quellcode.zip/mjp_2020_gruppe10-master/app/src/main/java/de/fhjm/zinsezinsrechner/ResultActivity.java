package de.fhjm.zinsezinsrechner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class ResultActivity extends BasicActivity implements View.OnClickListener {

    protected boolean savedCalculation;

    protected boolean accepted;

    private DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY);

    private String outputString;

    protected Button backButton;
    protected Button deleteButton;
    protected Button shareButton;
    protected Button saveButton;

    protected String searchedValue;

    protected Intent intent;

    protected EditText et_comment;

    protected TextView tv_variableA;
    protected TextView tv_variableB;
    protected TextView tv_variableC;
    protected TextView tv_result;
    protected TextView tv_variableA_text;
    protected TextView tv_variableB_text;
    protected TextView tv_variableC_text;
    protected TextView tv_result_text;
    protected TextView tv_date;

    protected Calculation calculation;

    protected DatabaseHelper mDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        boolean resultAddData;

        accepted = false;

        mDatabaseHelper = new DatabaseHelper(this);

        tv_variableA    = findViewById(R.id.tv_variableA);
        tv_variableB    = findViewById(R.id.tv_variableB);
        tv_variableC    = findViewById(R.id.tv_variableC);
        tv_result       = findViewById(R.id.tv_result);
        tv_date         = findViewById(R.id.tv_date);
        tv_variableA_text   = findViewById(R.id.tv_variableA_text);
        tv_variableB_text   = findViewById(R.id.tv_variableB_text);
        tv_variableC_text   = findViewById(R.id.tv_variableC_text);
        tv_result_text      = findViewById(R.id.tv_result_text);

        et_comment = findViewById(R.id.et_comment);

        deleteButton    = findViewById(R.id.deleteButton);
        backButton      = findViewById(R.id.backButton);
        shareButton     = findViewById(R.id.shareButton);
        saveButton      = findViewById(R.id.saveButton);

        intent = getIntent();

        calculation         = (Calculation)intent.getSerializableExtra("calculation");
        savedCalculation    = intent.getBooleanExtra("savedCalculation", false);
        searchedValue       = calculation.getSearchedValue();

        if(calculation.getSearchedValue().equals(getString(R.string.label_initialCapital))){

            calculation.calculateInitialCapital();
            tv_date.setText(dateFormat.format(calculation.getDate()));
            tv_variableA.setText(String.valueOf(calculation.getInterestRate()));
            tv_variableB.setText(String.valueOf(calculation.getOperationalTime()));
            tv_variableC.setText(String.valueOf(calculation.getFinalCapital()));
            tv_result.setText(String.valueOf(calculation.getInitialCapital()));
            et_comment.setText(calculation.getComment());
            tv_variableA_text.setText(getString(R.string.label_interestRate));
            tv_variableB_text.setText(getString(R.string.label_operationalTime));
            tv_variableC_text.setText(getString(R.string.label_finalCapital));
            tv_result_text.setText(getString(R.string.label_initialCapital));
            outputString = getString(R.string.label_output_1)
                    + getString(R.string.label_interestRate) + " = " + calculation.getInterestRate() + "\n"
                    + getString(R.string.label_operationalTime) + " = " + calculation.getOperationalTime() + "\n"
                    + getString(R.string.label_finalCapital) + " = " + calculation.getFinalCapital() + "\n"
                    + getString(R.string.label_output_2) + getString(R.string.label_initialCapital) + " bei " + calculation.getInitialCapital();

            if(savedCalculation){
                deleteButton.setVisibility(View.VISIBLE);
            }
            else {
                resultAddData = mDatabaseHelper.addData(calculation);
                if (resultAddData){
                    Toast.makeText(getApplicationContext(), getString(R.string.label_saved_successfull), Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), getString(R.string.label_saved_not_successfull), Toast.LENGTH_LONG).show();
                }
            }

        }else if(calculation.getSearchedValue().equals(getString(R.string.label_interestRate))){

            calculation.calculateInterestRate();
            tv_date.setText(dateFormat.format(calculation.getDate()));
            tv_variableA.setText(String.valueOf(calculation.getInitialCapital()));
            tv_variableB.setText(String.valueOf(calculation.getOperationalTime()));
            tv_variableC.setText(String.valueOf(calculation.getFinalCapital()));
            tv_result.setText(String.valueOf(calculation.getInterestRate()));
            et_comment.setText(calculation.getComment());
            tv_variableA_text.setText(getString(R.string.label_initialCapital));
            tv_variableB_text.setText(getString(R.string.label_operationalTime));
            tv_variableC_text.setText(getString(R.string.label_finalCapital));
            tv_result_text.setText(getString(R.string.label_interestRate));
            outputString = getString(R.string.label_output_1)
                    + getString(R.string.label_initialCapital) + " = " + calculation.getInitialCapital() + "\n"
                    + getString(R.string.label_operationalTime) + " = " + calculation.getOperationalTime() + "\n"
                    + getString(R.string.label_finalCapital) + " = " + calculation.getFinalCapital() + "\n"
                    + getString(R.string.label_output_2) + getString(R.string.label_interestRate) + " bei " + calculation.getInterestRate();

            if(savedCalculation){
                deleteButton.setVisibility(View.VISIBLE);
            }
            else {
                resultAddData = mDatabaseHelper.addData(calculation);
                if (resultAddData){
                    Toast.makeText(getApplicationContext(), getString(R.string.label_saved_successfull), Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), getString(R.string.label_saved_not_successfull), Toast.LENGTH_LONG).show();
                }
            }

        }else if(calculation.getSearchedValue().equals(getString(R.string.label_operationalTime))){

            calculation.calculateOperationalTime();
            tv_date.setText(dateFormat.format(calculation.getDate()));
            tv_variableA.setText(String.valueOf(calculation.getInitialCapital()));
            tv_variableB.setText(String.valueOf(calculation.getInterestRate()));
            tv_variableC.setText(String.valueOf(calculation.getFinalCapital()));
            tv_result.setText(String.valueOf(calculation.getOperationalTime()));
            et_comment.setText(calculation.getComment());
            tv_variableA_text.setText(getString(R.string.label_initialCapital));
            tv_variableB_text.setText(getString(R.string.label_interestRate));
            tv_variableC_text.setText(getString(R.string.label_finalCapital));
            tv_result_text.setText(getString(R.string.label_operationalTime));
            outputString = getString(R.string.label_output_1)
                    + getString(R.string.label_interestRate) + " = " + calculation.getInterestRate() + "\n"
                    + getString(R.string.label_initialCapital) + " = " + calculation.getInitialCapital() + "\n"
                    + getString(R.string.label_finalCapital) + " = " + calculation.getFinalCapital() + "\n"
                    + getString(R.string.label_output_2) + getString(R.string.label_operationalTime) + " bei " + calculation.getOperationalTime();

            if(savedCalculation){
                deleteButton.setVisibility(View.VISIBLE);
            }
            else {
                resultAddData = mDatabaseHelper.addData(calculation);
                if (resultAddData){
                    Toast.makeText(getApplicationContext(), getString(R.string.label_saved_successfull), Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), getString(R.string.label_saved_not_successfull), Toast.LENGTH_LONG).show();
                }
            }

        }else if(calculation.getSearchedValue().equals(getString(R.string.label_finalCapital))){

            calculation.calculateFinalCapital();
            tv_date.setText(dateFormat.format(calculation.getDate()));
            tv_variableA.setText(String.valueOf(calculation.getInitialCapital()));
            tv_variableB.setText(String.valueOf(calculation.getInterestRate()));
            tv_variableC.setText(String.valueOf(calculation.getOperationalTime()));
            tv_result.setText(String.valueOf(calculation.getFinalCapital()));
            et_comment.setText(calculation.getComment());
            tv_variableA_text.setText(getString(R.string.label_initialCapital));
            tv_variableB_text.setText(getString(R.string.label_interestRate));
            tv_variableC_text.setText(getString(R.string.label_operationalTime));
            tv_result_text.setText(getString(R.string.label_finalCapital));
            outputString = getString(R.string.label_output_1)
                    + getString(R.string.label_interestRate) + " = " + calculation.getInterestRate() + "\n"
                    + getString(R.string.label_operationalTime) + " = " + calculation.getOperationalTime() + "\n"
                    + getString(R.string.label_initialCapital) + " = " + calculation.getInitialCapital() + "\n"
                    + getString(R.string.label_output_2) + getString(R.string.label_finalCapital) + " bei " + calculation.getFinalCapital();


            if(savedCalculation){
                deleteButton.setVisibility(View.VISIBLE);
            }
            else {
                resultAddData = mDatabaseHelper.addData(calculation);
                if (resultAddData){
                    Toast.makeText(getApplicationContext(), getString(R.string.label_saved_successfull), Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), getString(R.string.label_saved_not_successfull), Toast.LENGTH_LONG).show();
                }
            }
        }

        backButton.setOnClickListener(this);
        deleteButton.setOnClickListener(this);
        shareButton.setOnClickListener(this);
        saveButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.deleteButton:
                mDatabaseHelper.deleteData(calculation.getId());
                finish();
                startActivity(new Intent(this, SavedcalculationsActivity.class));
                break;

            case R.id.backButton:
                if(calculation.getComment() == null) {
                    if(et_comment.getText().toString().equals("")){
                        finish();
                    }else{
                        if (accepted) {
                            accepted = false;
                            finish();
                        } else {
                            Toast.makeText(getApplicationContext(), getString(R.string.label_sure), Toast.LENGTH_LONG).show();
                        }
                        accepted = true;
                    }
                }else{
                    if (!calculation.getComment().equals(et_comment.getText().toString())) {
                        if (accepted) {
                            accepted = false;
                            finish();
                        } else {
                            Toast.makeText(getApplicationContext(), getString(R.string.label_sure), Toast.LENGTH_LONG).show();
                        }
                        accepted = true;
                    } else {
                        finish();
                    }
                }
                break;

            case R.id.shareButton:
                intent = new Intent();
                intent.setAction(Intent.ACTION_SEND);
                outputString = getString(R.string.label_whatsApp) + outputString;
                intent.putExtra(Intent.EXTRA_TEXT, outputString);
                intent.setType("text/plain");
                startActivity(intent);
                break;

            case R.id.saveButton:
                if (calculation.getComment() != null){
                    if (!calculation.getComment().equals(et_comment.getText().toString())){
                        calculation.setComment(et_comment.getText().toString());
                        mDatabaseHelper.updateData(calculation);
                    }
                    break;
                }
                else{
                    if (!et_comment.getText().toString().equals("")){
                        calculation.setComment(et_comment.getText().toString());
                        mDatabaseHelper.updateData(calculation);
                    }
                }
        }
    }

    @Override
    protected int getLayoutResourceId() {
        return R.layout.activity_result;
    }

}
