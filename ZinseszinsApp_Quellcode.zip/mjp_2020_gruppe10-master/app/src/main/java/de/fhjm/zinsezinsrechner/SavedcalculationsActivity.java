package de.fhjm.zinsezinsrechner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class SavedcalculationsActivity extends BasicActivity implements AdapterView.OnItemClickListener {

    protected DatabaseHelper mDatabasehelper = new DatabaseHelper(this);

    protected Intent intent;

    private ArrayList<Calculation> calculationList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        calculationList = mDatabasehelper.getData();

        ListView listView = findViewById(R.id.lv_savedcalculations);
        ListviewAdapter adapter = new ListviewAdapter(this, calculationList);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);

    }

    @Override
    protected int getLayoutResourceId() {
        return R.layout.activity_savedcalculations;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Calculation clickedCalculation = calculationList.get(position);
        intent = new Intent(this, ResultActivity.class);
        intent.putExtra("calculation", clickedCalculation);
        intent.putExtra("savedCalculation", true);
        startActivity(intent);
    }
}
