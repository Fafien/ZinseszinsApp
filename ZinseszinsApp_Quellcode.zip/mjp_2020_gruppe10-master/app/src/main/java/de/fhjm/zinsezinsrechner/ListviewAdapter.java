package de.fhjm.zinsezinsrechner;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class ListviewAdapter extends BaseAdapter {
    private ArrayList<Calculation> calculationList;
    private Activity activity;

    ListviewAdapter(Activity activity, ArrayList<Calculation> calculationList) {
        super();
        this.activity = activity;
        this.calculationList = calculationList;
    }

    @Override
    public int getCount() {
        return calculationList.size();
    }

    @Override
    public Object getItem(int position) {
        return calculationList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private static class ViewHolder {
        TextView mSearchedValue;
        TextView mInitialCapital;
        TextView mInterestRate;
        TextView mOperationalTime;
        TextView mFinalCapital;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        LayoutInflater inflater = activity.getLayoutInflater();

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.listview_row, null);
            holder = new ViewHolder();
            holder.mSearchedValue   = convertView.findViewById(R.id.savedCalculations_searchedValue);
            holder.mInitialCapital  = convertView.findViewById(R.id.savedCalculations_initialCapital);
            holder.mInterestRate    = convertView.findViewById(R.id.savedCalculations_interestRate);
            holder.mOperationalTime = convertView.findViewById(R.id.savedCalculations_operationalTime);
            holder.mFinalCapital    = convertView.findViewById(R.id.savedCalculations_finalCapital);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Calculation item = calculationList.get(position);
        holder.mSearchedValue.setText(item.getSearchedValue());
        holder.mInitialCapital.setText(String.valueOf(item.getInitialCapital()));
        holder.mInterestRate.setText(String.valueOf(item.getInterestRate()));
        holder.mOperationalTime.setText(String.valueOf(item.getOperationalTime()));
        holder.mFinalCapital.setText(String.valueOf(item.getFinalCapital()));

        return convertView;
    }
}
